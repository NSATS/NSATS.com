# NSATS Sans 1.203 — Web Kit

Everything a web developer needs to use NSATS Sans on a website: the six WOFF2 fonts, ready-made CSS, an optional metric-adjusted fallback, a Sass partial, design tokens, Tailwind and Next.js snippets, examples and a loading check.

NSATS Sans is the NSATS typeface (formerly NSATS Clear), a modified version of IBM Plex Sans 3.005. Licence: SIL Open Font License 1.1 (`OFL.txt`).

## Contents

| Path | What it is |
|---|---|
| `fonts/woff2/` | NSATSSans-Regular, -Italic, -SemiBold, -SemiBoldItalic, -Bold, -BoldItalic (`.woff2`) |
| `css/nsats-sans.css` | `@font-face` rules for the six faces, the `--font-nsats` variable and helper classes |
| `css/nsats-sans-fallback.css` | optional "NSATS Sans Fallback" (local Arial or Liberation Sans, adjusted towards NSATS Sans's average width and line metrics) |
| `css/fallback-metrics.json` | the computed fallback values |
| `scss/_nsats-sans.scss` | Sass partial: font faces, `$nsats-font-stack`, `@mixin nsats-text` |
| `tokens/nsats-sans.tokens.json` | design tokens in the Design Tokens Format Module 2025.10 (font family and the three weights; the format defines no font-style type, so italic is not a token) |
| `frameworks/tailwind/` | Tailwind CSS v3 config snippet and v4 `@theme` snippet |
| `frameworks/nextjs/` | Next.js `next/font/local` setup (`nsats-sans.ts`) with a complete example (`layout.example.tsx`, `globals.example.css`) |
| `examples/` | `self-hosted.html` and `hosted.html` |
| `test/check.html` | loads all six faces and reports PASS/FAIL |
| `package.json` | package description (marked private so it cannot be published to npm by accident) |
| `OFL.txt`, `FONTLOG.txt` | licence and history |

## Quick start

### Option A — self-host (recommended for production)

1. Copy `css/` and `fonts/` to your site, keeping them side by side.
2. In every page's `<head>`:

```html
<link rel="preload" href="/assets/nsats-sans/fonts/woff2/NSATSSans-Regular.woff2" as="font" type="font/woff2" crossorigin>
<link rel="stylesheet" href="/assets/nsats-sans/css/nsats-sans.css">
<link rel="stylesheet" href="/assets/nsats-sans/css/nsats-sans-fallback.css">  <!-- optional -->
```

3. Use the font:

```css
body { font-family: var(--font-nsats); font-kerning: normal; font-synthesis: none; }
h1, h2 { font-weight: 600; }
strong { font-weight: 700; }
```

### Option B — load from the NSATS site

```html
<link rel="stylesheet" href="https://nsats.github.io/NSATS.com/fonts/nsats-sans/1.203/css/nsats-sans.css">
```

This serves the fonts from GitHub Pages and works only once version 1.203 is published there. Loading fonts from another site depends on that site's cross-origin (CORS) headers and caching, which have not yet been tested for this address; check it in your browser before relying on it. It is convenient for prototypes and internal pages; for production, self-host so that availability, caching and privacy are under your control.

## Styles and weights

| Face | CSS | Menu name in Microsoft Office and other four-style menus |
|---|---|---|
| Regular | `font-weight: 400; font-style: normal` | NSATS Sans |
| Italic | `400 italic` | NSATS Sans |
| SemiBold | `600 normal` | NSATS Sans SemiBold |
| SemiBold Italic | `600 italic` | NSATS Sans SemiBold |
| Bold | `700 normal` | NSATS Sans |
| Bold Italic | `700 italic` | NSATS Sans |

There is no Light (300), Medium (500) or variable font. Ask for 400/600/700 only; with `font-synthesis: none` the browser will not fake bold or italic.

## Typography features

- **Kerning** is in the font; keep `font-kerning: normal` (the default in most browsers).
- **Figures** are tabular (equal width) by default. Use `font-variant-numeric: proportional-nums` (class `.nsats-proportional`) for running text if you prefer.
- **Accents**: 388 characters, including Latin Extended-A, and 15 combining accents that the font positions with its `mark` and `mkmk` features. In browsers that apply these features, decomposed (NFD) sequences for the supported letters are designed to display like the composed (NFC) letters; this has been checked for test strings, not for every combination. Stacked accents outside the character set have known limitations (see the distribution's `RELEASE-NOTES.txt`).
- **Languages**: English and Western European languages, plus Central European, Baltic, Turkish, Maltese, Esperanto and Welsh. Not included: Romanian comma-below letters (Ș ș Ț ț, U+0218–U+021B), Vietnamese, Greek and Cyrillic; the browser uses the next font in the stack for those.

## Fallback and layout shift

`nsats-sans-fallback.css` defines "NSATS Sans Fallback" from the visitor's own Arial (or Liberation Sans), adjusted with `size-adjust` and line-metric overrides (values in `css/fallback-metrics.json`).

How the values were calculated: for each face, the average advance width of one English prose calibration sample (below) in NSATS Sans was divided by the same average in Liberation Sans, whose advance widths match Arial's. This uses the fonts' unshaped advance widths — no kerning, shaping or browser rounding. Ascent and descent overrides reproduce NSATS Sans's line metrics (hhea 1025 / 275, line gap 0) at the adjusted size.

What this means:
- For text similar to the sample, the fallback's average width and line height approximate NSATS Sans, which can reduce layout shift when the web font arrives. On the sample itself the calculated width difference falls from 1.1–2.2 % (unadjusted Arial widths) to below 0.01 %.
- It is not a guarantee for other text. Example: for the digits 0123456789, Arial's advance widths are 7.31 % narrower than NSATS Sans's; with the adjustment they are 5.70 % narrower in Regular and Italic, but 9.31 % narrower in SemiBold and SemiBold Italic and 8.30 % narrower in Bold and Bold Italic.
- Browsers round line metrics to whole pixels, so the fallback's line height can differ from NSATS Sans's by a pixel or two at some font sizes.
- Layout shift (CLS) has not been measured with this file. Check your own pages, for example with your browser's performance tools.

Calibration sample: "NSATS licenses quantum computing software and technology to partners worldwide. Clear communication helps people compare options and make informed decisions. The quick brown fox jumps over the lazy dog. Please review reference NSATS/2026/037 and confirm AED 12,450.00 before the meeting on Monday. Our research, engineering and compliance teams work together across Geneva and Dubai."

## Frameworks

- **Sass**: `@use "nsats-sans" with ($nsats-font-path: "/assets/nsats-sans/fonts/woff2");` then `@include nsats-sans.nsats-text(600);`. Uses the Sass module system (`@use`), so it needs Dart Sass; LibSass and node-sass are not supported.
- **Tailwind v3**: merge `frameworks/tailwind/tailwind.config.js`, load the CSS, then use `class="font-nsats"`.
- **Tailwind v4**: see `frameworks/tailwind/tailwind-v4.css`.
- **Next.js** (App Router): copy `frameworks/nextjs/nsats-sans.ts` into `app/` and `fonts/woff2/*.woff2` into `app/fonts/`. Then apply the font in one of two ways:
    - **A — CSS variable:** `<html lang="en" className={nsatsSans.variable}>` and, in `app/globals.css`, `body { font-family: var(--font-nsats); }`. The `.variable` class only defines `--font-nsats`; the `font-family` rule is what applies it. Complete example: `layout.example.tsx` and `globals.example.css`.
    - **B — class name:** `<html lang="en" className={nsatsSans.className}>`, which sets `font-family` directly.

    Do not also load `css/nsats-sans.css`; `next/font` generates its own `@font-face` rules and, with `adjustFontFallback: 'Arial'`, its own adjusted Arial fallback.
- **React / Vue / plain HTML**: import `css/nsats-sans.css` once (for example in your root layout) and use `var(--font-nsats)`.
- **E-mail**: most e-mail clients do not load web fonts. Use the stack `"NSATS Sans", Arial, sans-serif` so recipients without the font see Arial.

## Serving

- MIME type `font/woff2`; long cache lifetimes are safe because each version has its own file names and path.
- Fonts loaded from another origin need CORS (`Access-Control-Allow-Origin`). Cross-origin loading from the NSATS GitHub Pages address has not yet been tested.
- Keep each version under its own path (for example `/assets/nsats-sans/1.203/`) and never overwrite older files.

## Testing

Serve the kit folder (for example `python3 -m http.server`) and open `test/check.html`; it should report "6 of 6 faces loaded".

Tested for this kit on Linux only (7 October 2026): in headless Chromium 141 the check page loaded 6 of 6 faces; the Sass partial compiled with Dart Sass 1.105.1; the Tailwind snippets built with Tailwind CSS 3.4.19 and 4.3.3 (class `font-nsats` generated); the Next.js example built with Next.js 16.4.0 using each of the two methods, and the served page loaded all six faces. Not tested: browsers on Windows, macOS, iPhone and Android with this kit, cross-origin loading from the NSATS site, and layout shift.

## Licence

SIL Open Font License 1.1. You may use, copy, modify and redistribute the fonts; keep `OFL.txt` with them; do not sell the fonts by themselves; do not name modified versions "Plex" or use IBM's name to promote them. The licence's conditions apply to the fonts themselves; they do not extend to websites or documents that use the fonts.

## Integrity

`SHA256SUMS.txt` lists every file in the kit except itself. Check with `shasum -a 256 -c SHA256SUMS.txt`.
