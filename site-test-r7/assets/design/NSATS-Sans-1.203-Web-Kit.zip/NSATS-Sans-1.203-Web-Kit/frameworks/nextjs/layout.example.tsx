// Example app/layout.tsx (Next.js App Router), method A: CSS variable plus an explicit font-family rule.
// Place nsats-sans.ts and its fonts/ folder in app/, and the rules from globals.example.css in app/globals.css.
// Method B instead: className={nsatsSans.className} on <html>, and no font-family rule is needed.
import type { ReactNode } from 'react';
import { nsatsSans } from './nsats-sans';
import './globals.css';

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" className={nsatsSans.variable}>
      <body>{children}</body>
    </html>
  );
}
