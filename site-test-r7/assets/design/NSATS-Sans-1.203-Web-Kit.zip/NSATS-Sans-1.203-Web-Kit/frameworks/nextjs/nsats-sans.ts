// Next.js (App Router) with next/font/local. Copy fonts/woff2/*.woff2 into a "fonts" folder next to this file.
// Apply the font in ONE of two ways (complete example: layout.example.tsx + globals.example.css):
//   A) <html className={nsatsSans.variable}> defines the CSS variable --font-nsats only; you must also set
//      font-family: var(--font-nsats); in your CSS (for example on body, as in globals.example.css).
//   B) <html className={nsatsSans.className}> sets font-family directly; no extra CSS is needed.
// Do not also load the kit's css/nsats-sans.css: next/font generates its own @font-face rules.
import localFont from 'next/font/local';

export const nsatsSans = localFont({
  src: [
    { path: './fonts/NSATSSans-Regular.woff2', weight: '400', style: 'normal' },
    { path: './fonts/NSATSSans-Italic.woff2', weight: '400', style: 'italic' },
    { path: './fonts/NSATSSans-SemiBold.woff2', weight: '600', style: 'normal' },
    { path: './fonts/NSATSSans-SemiBoldItalic.woff2', weight: '600', style: 'italic' },
    { path: './fonts/NSATSSans-Bold.woff2', weight: '700', style: 'normal' },
    { path: './fonts/NSATSSans-BoldItalic.woff2', weight: '700', style: 'italic' },
  ],
  display: 'swap',
  variable: '--font-nsats',
  fallback: ['Helvetica Neue', 'Arial', 'sans-serif'],
  adjustFontFallback: 'Arial',
});
