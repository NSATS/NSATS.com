// Tailwind CSS v3: add NSATS Sans as the "nsats" family (class: font-nsats). Load css/nsats-sans.css (and the fallback CSS) globally.
module.exports = {
  theme: {
    extend: {
      fontFamily: {
        nsats: ['"NSATS Sans"', '"NSATS Sans Fallback"', '"Helvetica Neue"', 'Arial', 'sans-serif'],
      },
    },
  },
};
