# Command and behaviour reference

SDK design documentation · Draft 2 · 8 October 2026

These command forms describe the proposed software demonstration’s interactive interface. They are illustrative, not commands available in a released package. No C function signatures, header files or binary interface have been defined in this edition.

## Commands

| Command form | Intended purpose | Intended result |
| --- | --- | --- |
| `compress INPUT OUTPUT` | Start with an original file or continue from the current session output. | A new reduced file and session data. |
| `decompress INPUT OUTPUT` | Restore from a recognised session output. | A new file containing the original bytes. |
| `status INPUT` | Inspect a recognised file history. | Original and current byte counts, completed passes, session availability and compression eligibility. |
| `help` | Explain the available commands. | Usage guidance without changing files or session data. |
| `exit` | End the demonstration session. | Session data and keys are discarded when the session ends. |

`INPUT` and `OUTPUT` stand for file paths. They are not literal filenames. The prompt marker `nsats>` in examples is also not part of the command.

## Compression inputs and results

The first operation accepts an original file. Later operations need a recognised current output from that file's history. Each history keeps its original size and stopping threshold; neither is reset simply because the output has a new name.

An output destination must differ from the input and original file. The proposed safe default is to reject an existing destination rather than overwrite it. Path aliases must not bypass this protection.

On success, the operation should make the new output current. For a failure handled while the session is still running, it should leave the last valid output and its matching session data usable. After a crash, the file can remain on disk but cannot be restored without the lost session data. Exact treatment of older outputs, renamed files and copied outputs remains outside the draft contract.

## Restoration inputs and results

Restoration requires both the reduced file and its matching session data. The implementation should verify their association and integrity before presenting a restored file as complete.

The intended result is byte-for-byte equality with the original. This refers to file contents, not filesystem attributes. The treatment of session data after successful restoration must be defined before a software release.

## Conditions to report

| Condition | Intended response |
| --- | --- |
| Further compression is no longer permitted | Explain that the limit has been reached; preserve the current output and allow restoration. |
| Required session data is unavailable | Refuse restoration and report: “No matching session data is available.” Restarting the demonstration cannot recover a previous RAM-only session. |
| An input is unrecognised or has changed | Refuse to treat it as a valid session output. Do not guess its identity from its filename. |
| Integrity verification fails | Reject the operation without presenting damaged data as restored. |
| Destination already exists | Request a different destination under the proposed no-overwrite policy. |
| Input cannot be read, output cannot be completed, or memory is insufficient | Report the relevant failure; while the session is still running, preserve the last valid output and matching session data. |
| Command or arguments are invalid | Explain the expected command form without changing data. |

These are semantic conditions, not assigned API error codes. A complete error catalogue and exact user-facing messages belong to an implementation release.

## Boundaries still to be specified

Filename quoting, maximum file size, empty and very small files, byte rounding, the final compression pass, cancellation and repeated restoration need a precise implementation contract. Examples in this edition avoid depending on those choices.

See the [worked examples](04-worked-examples.md).
