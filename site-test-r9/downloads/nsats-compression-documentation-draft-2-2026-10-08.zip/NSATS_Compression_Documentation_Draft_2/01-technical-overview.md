# Compression and restoration technical overview

SDK design documentation · Draft 2 · 8 October 2026

The proposed software demonstration lets a reader follow a file through repeated size reductions and restoration within one running session. It describes the software workflow for a future C demonstration; no runnable SDK accompanies this edition.

This software demonstration holds removed bytes in the program’s memory; see the Temporal Compression technology page for the technology explanation.

## What the demonstration illustrates

A compression operation produces a smaller output file while retaining the information needed for restoration in the running program's memory. The decompression operation combines the matching output and session data to reproduce the original file contents.

The terms compressor and decompressor identify the two demonstration operations. The smaller output is dependent on the session that created it. Moving bytes into RAM reduces the output file size but does not reduce the total amount of information stored. Encryption, padding and bookkeeping would add further memory use.

This workflow illustrates file and session handling. It does not expose the implementation of licensed NSATS technology or establish its storage capacity, speed or security performance.

## Files and sessions

An original file starts a file history: the session data that tracks that original and its successive compression steps. Each compression step creates a new output in that history. Further compression uses the latest output and its session data. The original file remains unchanged.

The proposed interface lets the user choose each output filename. A filename identifies where a file is stored; it must not be the sole basis for deciding which session data belongs to that file.

Restoration means reproducing the original sequence of bytes. Preservation of file permissions, timestamps and other filesystem attributes is outside this draft's restoration scope.

## Repeated compression

Each pass removes a small, randomly selected proportion of the current file size. A stopping threshold is selected once for the original file and defines the remaining output size the reduced file may reach. It remains associated with that file's history throughout the session.

Further compression stops at the permitted limit. Restoration remains available while the matching output and session data are intact. The precise rounding and final-pass rules require an implementation specification before executable examples can be supplied.

## Ending the session

The intended interactive prompt keeps the program running between commands. Exiting, a process crash or restarting the computer loses the session data. Closing the terminal also loses that data if it ends the demonstration process. Starting a new session does not recover it from an earlier output file.

Keep the original file. A reduced output from this demonstration is not a standalone archive or a backup.

## Reading next

Read the [SDK workflow guide](02-sdk-workflow-guide.md) for the intended sequence and the [worked examples](04-worked-examples.md) for illustrative outcomes.
