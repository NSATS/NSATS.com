# Compression demonstration security design

SDK design documentation · Draft 2 · 8 October 2026

The proposed software demonstration security design protects session data and detects invalid changes while making casual inspection more difficult. These are design objectives; this edition does not report implemented or tested protections.

## Retained information

The intended design encrypts retained file data and the information needed to reconstruct it. Integrity checks should bind that information to the correct file history and step, so altered data or records from another history are rejected.

Authenticated encryption combines confidentiality with a check for modification. A maintained cryptographic library should provide this function rather than a new proprietary cipher. [Encrypting a set of related messages](https://doc.libsodium.org/secret-key_cryptography/encrypted-messages)

## Session keys and temporary data

A session key should be generated securely for each run and should not be embedded in the distributed program. Protected memory allocation, supported memory locking and secure erasure can reduce accidental exposure of keys and temporary plaintext. These mechanisms require platform-specific handling. Swap and hibernation can expose memory contents on disk, and ordinary process memory remains accessible to a sufficiently privileged observer. [Secure memory](https://doc.libsodium.org/memory_management)

Input and restored file contents necessarily become available to the application during processing. Encryption of session data is not encryption of every input, output or temporary byte at all times.

## Padding

Padding adds unused bytes around meaningful data. It can obscure the useful length inside an encrypted block, but increases memory use. It does not hide the size of the input and output files, their difference or all memory allocation patterns.

## Program integrity

Release signing and operating-system protections can reduce certain forms of code injection and unauthorised modification. For example, Apple's Hardened Runtime restricts classes of injection and process-memory tampering when correctly configured. Protections and prerequisites differ by platform. [Apple Hardened Runtime](https://developer.apple.com/documentation/security/hardened-runtime)

These measures cannot establish that an arbitrary computer controlled by an observer will execute the program without inspection. Displayed text, public commands and output behaviour remain observable.

## Protecting implementation knowledge

The documentation explains the demonstration's external workflow. It does not disclose the proprietary NSATS implementation. Any future distribution should retain that separation: the demonstration and examples need only the logic necessary to illustrate the agreed workflow.

Security claims should identify what was implemented, the environment assessed and the remaining exposure. A documentation draft alone establishes none of those test results.
