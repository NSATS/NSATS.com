# Compression demonstration software integration guide

SDK design documentation · Draft 2 · 8 October 2026

An application using the proposed software demonstration would manage file selection, session lifetime, operation results and destination files. The interface described here is a design for discussion; an implementation release would need to supply its actual C API or supported command interface.

## Define the application task

Identify who chooses the file, where results should be written and when restoration is required. Keep the original accessible until the application has verified the restored contents. The reduced output depends on session data and cannot serve as an independent backup.

The application should distinguish an original input from an output already associated with the current session. A file extension alone cannot establish that distinction.

## Keep the session available

Compression, inspection and restoration share the same live session. Starting a separate short-lived process for each command would lose ordinary in-process arrays when that process exits.

A future integration therefore needs either a long-running demonstration process or another explicitly defined session owner. This draft assumes the interactive process remains running. It does not define a background service, cross-process shared memory or persistent recovery store.

## Coordinate operations

For the initial design, sequence operations on a file history: complete a compression pass before starting the next pass or restoration. Concurrent changes to the same history need separate implementation rules.

Track completion independently from file existence. A file may exist even when an operation was interrupted. Only a verified completed result should become the input to another operation.

Treat user-supplied paths as data. An integration must not concatenate them into commands for an operating-system shell.

## Handle failure

Distinguish unavailable session data, invalid input, an integrity failure, the compression limit and a failure to read, allocate memory or write output. The application should explain which action remains possible without presenting a partial result as complete.

A failed or interrupted operation handled while the session is still running should preserve the last valid output and matching session data. A crash can leave the output file on disk but loses the session data needed to restore it. Retrying must not accidentally remove data twice or create a second committed step for the same failed request. The exact cancellation and retry contract belongs to the implementation specification.

## Verify restoration

Compare the restored bytes against the original for representative file types and sizes. Include repeated passes, multiple independent histories, changed outputs and termination between operations. These checks establish the behaviour of the demonstration implementation under test; they do not measure the licensed technology's performance.

A total-workflow resource assessment should count the original file, current and earlier output files, restored copies and temporary files on disk, together with session data, padding, metadata and peak temporary working memory. Reporting only the smaller current output omits these other storage and memory costs.

## Match documentation to a release

Before an integration can be built, it needs a named software version, supported environment, actual interface contract, file format, error definitions and repeatable verification results. This documentation revision does not assign those values.

See the [workflow guide](02-sdk-workflow-guide.md), [command reference](03-command-reference.md) and [security overview](06-security-overview.md).
