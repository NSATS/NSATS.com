# Compression and restoration worked examples

SDK design documentation · Draft 2 · 8 October 2026

These examples illustrate the proposed software demonstration’s command flow. They are not execution transcripts or test results. The filenames and `.demo` extension are illustrative and do not define a released file format.

## Compress and restore

Begin with an original file named `sample.dat` and two unused destination names.

```text
nsats> compress sample.dat sample-step1.demo
nsats> status sample-step1.demo
nsats> decompress sample-step1.demo restored.dat
```

The intended first result is a smaller `sample-step1.demo` plus its matching session data. The status request describes that file history. Restoration writes `restored.dat`, whose contents should match `sample.dat` exactly.

## Repeat compression

Start a fresh example session with the original sample.dat still available. Use the unused repeat-step1.demo, repeat-step2.demo and repeat-restored.dat destinations below; files from the first example can remain on disk.

```text
nsats> compress sample.dat repeat-step1.demo
nsats> compress repeat-step1.demo repeat-step2.demo
nsats> status repeat-step2.demo
nsats> decompress repeat-step2.demo repeat-restored.dat
```

The second pass acts on the first output. Its percentage therefore applies to a smaller file. Restoration from the second output uses the session data for both passes and targets the original contents.

As an arithmetic illustration, consider a file of 1,000,000 bytes and a removal of 3% on each of two passes. The outputs would contain 970,000 bytes and 940,900 bytes. Across those passes, 59,100 bytes have been moved out of the file into session data, before encryption, padding and metadata overhead. These figures are chosen demonstration arithmetic, not NSATS technology performance measurements. Actual planned pass percentages vary.

## Reach the limit

After several successful passes, a status request indicates that further compression is unavailable. A further `compress` request should leave the current output unchanged and explain the limit. The user can still request restoration within the session.

No final byte count is specified in this example because final-pass rounding and threshold crossing remain implementation decisions.

## Lose the session

If the user exits after creating a reduced output, the session data is lost. A new session may still be able to read the output file from disk, but cannot reconstruct its missing information.

The intended response is a refusal to restore: “No matching session data is available.” The original remains the recovery source. Reopening the program is not a way to recover discarded RAM.

## Supply changed data

If a reduced file is modified before restoration, the implementation should reject it when verification fails. It must not silently combine changed bytes with a different history or report successful restoration merely because a file was written.

See the [command reference](03-command-reference.md) for the corresponding conditions and the [security overview](06-security-overview.md) for the planned integrity protections.
