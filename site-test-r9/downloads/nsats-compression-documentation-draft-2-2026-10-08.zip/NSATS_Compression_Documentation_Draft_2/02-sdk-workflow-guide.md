# SDK workflow guide

SDK design documentation · Draft 2 · 8 October 2026

The proposed C software demonstration provides an interactive prompt for compressing and restoring files in one session. The steps below describe intended operation. They are not installation instructions for released software.

## Prepare a file

Use a copy of a file whose contents can be checked after restoration. Keep the original available throughout the exercise. Choose a new destination name for each result.

The initial implementation scope should use ordinary files. Directories, devices and special filesystem objects require separate handling and are not covered by these examples.

## Start a session

The proposed program opens its own command prompt. Commands are interpreted by the demonstration rather than passed to the operating system's shell.

A fresh session begins without session data from earlier runs. Reading an earlier reduced file does not restore the session data.

## Create the first output

Supply the original file and a destination name to the compression operation. The intended result is a smaller output with matching session data retained for restoration. The original file remains available.

The operation should report completion only after both the output file and its matching session record are ready. A partial or failed operation must not be presented as a usable result.

## Continue or inspect

Use the current output as the input to the next compression step, choosing a new destination name. A status request should identify the original size, current size, number of completed steps and whether further compression is available.

If the permitted limit has been reached, keep the current output and either restore the original contents or end the exercise. The documentation does not prescribe a fixed number of passes.

## Restore the original contents

Provide the latest output and a new destination name to the decompression operation within the same session. The intended result is a file containing exactly the original bytes.

Check its size and compare its contents with the original. Matching file sizes alone do not establish that restoration succeeded.

## Close the session

Ending the session discards the session data and session keys. The interface should make this consequence clear before exit. Previously written files remain on disk, but their presence does not preserve the session data.

## Availability

This edition supplies documentation and illustrative command syntax. Executable names, installation steps, operating-system support and software download details will belong to a separately identified implementation release.

See the [command reference](03-command-reference.md) and [integration guide](05-integration-guide.md).
