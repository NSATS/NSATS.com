# NSATS compression and restoration documentation

SDK design documentation · Draft 2 · 8 October 2026

This edition describes a proposed C software demonstration. It contains no executable software or released API. Examples are illustrative, and security controls are design objectives.

1. [Technical overview](01-technical-overview.md)
2. [SDK workflow guide](02-sdk-workflow-guide.md)
3. [Command and behaviour reference](03-command-reference.md)
4. [Worked examples](04-worked-examples.md)
5. [Software integration guide](05-integration-guide.md)
6. [Security design overview](06-security-overview.md)

Read the overview before applying the workflow. The reduced output depends on session data and is not a standalone backup. These documents describe the demonstration, not measured performance of licensed NSATS technology.
