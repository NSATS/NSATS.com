# NSATS Clear: tester guide (release candidate 04)

This guide explains how to test NSATS Clear 1.100 (release candidate 04) on your assigned platforms and send back evidence. Your results decide whether the font is ready for NSATS letters, reports and the website. This is a test release, not production approval.

- **The font:** six styles, Regular, Italic, SemiBold, SemiBold Italic, Bold and Bold Italic, each covering the 234-character Western European set. See the [README](../README.md).
- **One round:** this release adds the Western European characters to everything tested before, so one round of tests covers it all.
- **Already checked:** the font files pass automatic checks on Linux, in LibreOffice and Chrome.
- **Not yet tested:**
  - Windows, Mac, iPhone and Android
  - Microsoft Word and Outlook
  - print

  Those are what you are testing.

## Before you start

- **Files:** download this repository (the green Code button, then Download ZIP) or clone it. Everything you need is inside.
- **Web tests (W1–W7)** need no installation. Use test page version 1.6 (shown in the copied results), which includes all six styles and all 234 characters. Use either:
  - **the hosted test page**, if A has shared its claude.ai link with you as a Contributor. Your results save straight to A. If its header does not say "1.100 · release candidate 04", it is an older version: use the file below instead, or ask A.
  - **`testing/web-test/NSATS Clear font test.html`** from this repository. Open it in the browser for your row. It carries its own copy of the fonts and works offline. Saving is not available in this copy, so use **Copy results** and email the text.
- **Document tests (E1, E2, E6) and the hinting test (H1)** need the font files installed. Install only on a test computer, and remove them afterwards.
- **Remove earlier versions first.** If you installed NSATS Clear 1.000 for an earlier round, uninstall all its files (and any Hinted Test files) and restart the computer before installing these.
- **Check the version after installing:** it must read **Version 1.100**.
  - Windows: right-click the .ttf file, then Properties, then Details.
  - Mac: Font Book, then Info.
- **Time:** about 15 minutes per web row, 40 minutes per Word row and 20 minutes for H1.
- **Your assignment:** A tells you which rows below are yours. Use one device and one browser or app per row.

## Test matrix

Every row needs its own run. A row nobody runs is reported as untested, not as passed.

| Row | Device and system | App | What you test | Evidence |
| --- | --- | --- | --- | --- |
| W1 | Windows 11 PC | Microsoft Edge | Web test page | Results + full-page screenshot |
| W2 | Windows 11 PC | Google Chrome | Web test page | Results + full-page screenshot |
| W3 | Windows 11 or Mac (say which) | Mozilla Firefox | Web test page | Results + full-page screenshot |
| W4 | Mac | Safari | Web test page | Results + full-page screenshot |
| W5 | Mac | Google Chrome | Web test page | Results + full-page screenshot |
| W6 | iPhone | Safari | Web test page | Results + full-page screenshot |
| W7 | Android phone (record the model) | Google Chrome | Web test page | Results + full-page screenshot |
| E1 | Windows 11 PC | Word (Microsoft 365 desktop) | Word test document | .docx + PDF + screenshots |
| E2 | Mac | Word for Mac | Word test document | .docx + PDF + screenshots |
| E3 | Any | Adobe Acrobat Reader | The E1 PDF | Fonts-tab screenshot + results form |
| E4 | Mac | Preview | The E2 PDF | Screenshots + results form |
| E5 | Any printer (record the model) | Print of the E3 or E4 PDF | Physical print | Scan or clear photo + results form |
| E6 | Windows 11 PC | Outlook (desktop) | Compose and receive an email | Screenshots + results form |
| H1 | Windows 11 PC | Word | Release fonts vs Hinted Test fonts | Screenshots at 100% and 125% + results form |

## Website tests (W1–W7)

1. **Open the test page in the browser for your row.** Use the hosted link or the HTML file. On a phone, open it in Safari or Chrome itself, not inside another app. Set browser zoom to 100%.
2. **Fill in Your setup:**
    - **Device model.** On Android: Settings, then About phone.
    - **Operating system and build:**
        - Windows: Settings, then System, then About.
        - Mac: Apple menu, then About This Mac.
        - iPhone: Settings, then General, then About.
    - **Browser version, from its About page:**
        - Edge: Settings, then About Microsoft Edge.
        - Chrome: ⋮, then Help, then About Google Chrome. On Android: Settings, then About Chrome.
        - Firefox: ☰, then Help, then About Firefox.
        - Safari on Mac: the Safari menu, then About Safari.
        - Safari on iPhone: record the iOS version.
    - **Display scaling.**
    - **Where you opened the page.**
3. **Wait for Automatic checks.** Thirteen checks run in a few seconds and should all say PASS. A check that says CHECK is a finding: mention it in the matching test sheet's note.
4. **Judge each test sheet, T2 to T12.** T12 shows Western European text; T8 includes a hidden hyphenation test. Choose Pass, Issue or Not sure. Add a note for anything other than Pass: which line, which style, what you saw.
5. **Take a full-page screenshot.** If a full-page capture shows only part of the page, take several overlapping screenshots.
    - Edge: Ctrl+Shift+S, then Capture full page.
    - Firefox: right-click, then Take Screenshot, then Save full page.
    - Chrome and Safari on Mac: several screenshots while scrolling, or File, then Export as PDF in Safari.
    - iPhone: take a screenshot, tap the preview, then Full Page.
    - Android: take a screenshot, then Capture more.
6. **Send your results.** On the hosted page, press **Save results**. Otherwise press **Copy results** and paste the text into your email with the screenshots.

## Document tests (E1–E6)

### Install the fonts (E1, E2, E6)

1. Install only the six files in `fonts/ttf`. Install the Hinted Test files only for H1.
2. **Windows:** select the six files, right-click, then Install.
3. **Mac:** double-click each file, then Install Font.
4. Quit and reopen Word or Outlook.

### E1 Word for Windows and E2 Word for Mac

Open `testing/word-test/NSATS Clear Word test (E1-E2).docx` and follow it from top to bottom. Its instructions are in Arial and every specimen is in NSATS Clear. It covers:

- your setup, including the Word version and editing language;
- the AutoCorrect test: typing (c), (r), (tm), 1/2, 1/4, 3/4, --> and <--;
- all 229 printable characters in each style;
- the six styles with underline;
- SemiBold in Word: the font list, and what Ctrl+B and Ctrl+I do on SemiBold text (Cmd+B and Cmd+I on Mac);
- sizes and the zero;
- figures in a table;
- line spacing;
- Western European text in several languages;
- a verdict table.

Record AutoCorrect settings as they are, with a screenshot of the AutoCorrect and AutoFormat As You Type tabs. Do not change them.

**Save and export.** Save the file as `NSATS Clear test - E1 - <your name>.docx` (E2 on Mac), then export a PDF with the same name:

- Windows: File, then Save As, then PDF.
- Mac: File, then Save As, then PDF, choosing "Best for printing".

The reference PDF beside the test document shows how it should look. It was rendered by LibreOffice on Linux, not by Word.

### E3 Acrobat Reader (the E1 PDF)

1. Go to File, then Properties, then Fonts, and take a screenshot. Body text should use only NSATSClear-Regular, -Italic, -SemiBold, -SemiBoldItalic, -Bold and -BoldItalic, each marked "Embedded Subset". Note any other font and the character it belongs to.
2. Select all, copy, and paste into Notepad. Check that the accents (including section 9, such as Größe, Ação, Ærø, Þingvellir), £, €, ½ and the arrows survive.
3. Search for "Quarterly", "£" and "Größe".

### E4 Preview on Mac (the E2 PDF)

1. View the PDF at 100% and 200%.
2. Copy the text into TextEdit and search it.
3. If Acrobat Reader is installed, also record its Fonts tab, as in E3.

### E5 Physical print

1. Print the E3 or E4 PDF on plain A4 at Actual size (100%).
2. Record the printer model and quality setting.
3. Check that:
    - 9–11 pt text is clear;
    - 0, O and 8 are distinct at 9 pt;
    - bold, italic and underlines look right.
4. Scan the page at 300 dpi, or photograph it flat.

### E6 Outlook for Windows (desktop)

1. Record whether it is classic or new Outlook, and its version.
2. In a new email, choose NSATS Clear in the message's font box. Do not change Outlook's default fonts.
3. Type the sample line in Regular, Italic, Bold and Bold Italic, and once more in NSATS Clear SemiBold, plus £ € ½ © and a few accented words such as Größe, Ação, Ærø.
4. Send the email to yourself and to a colleague without the font. Take screenshots of the email while composing, as you received it, and as the colleague received it.
5. Expect the colleague to see a substitute font, because emails do not carry fonts. Record it, but it is not a failure.

## Windows hinting comparison (H1)

1. On one Windows 11 PC, install `fonts/ttf` and `fonts/windows-hinting-comparison-only`. The second set appears as "NSATS Clear Hinted Test" and "NSATS Clear Hinted Test SemiBold".
2. In Word, make two identical blocks: one in NSATS Clear and one in NSATS Clear Hinted Test. Use the line `e é è a s c 0O8D 10080 Quarterly Report 2026 ÅÉÖ àâñ ß` at 8, 9, 10, 11 and 12 pt, in Regular, Bold and Italic. Add the same line in NSATS Clear SemiBold and NSATS Clear Hinted Test SemiBold.
3. Take screenshots with the Snipping Tool, saved as PNG and not resized:
    - with display scale at 100% and Word zoom at 100%;
    - again at 125% display scale.
4. For each size, record which family is clearer. Look especially at whether the holes in Bold and SemiBold e, é and è fill in, and whether 0 and O can be told apart at 10–12 pt.
5. Uninstall the Hinted Test fonts afterwards.

## What counts as an issue

| Severity | Examples |
| --- | --- |
| Blocker | A character from the 234 shows in another font or as an empty box. Bold, SemiBold or italic does not appear in Word or the PDF. The PDF lists another font for body text. Copied text changes characters. |
| Major | Accents or descenders are cut off, or an accent sits clearly off its letter. Figures do not line up. 0 is confusable with O, 8 or D in normal text. Two letters touch or leave an obvious gap (name the pair). An underline is missing or collides with letters. |
| Minor | Spacing or shape details you would only notice up close. |

**Known limitations.** Do not report these as new issues; note them only if you see something worse than described.

- Characters outside the 234, such as Central European ł, ő and č, appear in another font.
- The soft hyphen is drawn as a hyphen where a line breaks. If a browser or Word shows it inside a line, or not at a break, that is a finding (T8, T8s): report it.
- æ, œ, ª, º and ¹ ² ³ are new constructions and may draw design comments: note them in T12 or Word section 9.
- The fraction slash ⁄ does not build fractions: in T12, "1⁄8" shows full-size figures. That is expected.
- At 11–16 px on screen the dot in the Bold zero can blur. A recent study kept the current zero.
- Regular and Bold underlines differ slightly by design.
- Line spacing matches IBM Plex Sans.
- The italics are slanted forms of the uprights.
- In Word, SemiBold is listed as its own font, NSATS Clear SemiBold. Ctrl+B on SemiBold text may not switch to NSATS Clear Bold. Record what happens in section 5 of the Word test; it is not a new issue.
- Email recipients without the font see a substitute.
- Word AutoCorrect may insert symbols from another font, or leave triggers unchanged. That is Word's behaviour.

## Sending results

Email A one message per row, with files named `NSATS Clear test - <row> - <your name> - <date>`.

- **Web rows:** your saved run or your copied results, plus screenshots.
- **Document rows and H1:** the .docx, the PDF, screenshots, the print scan as applicable, and the completed [results form](results-form.md).

## Rules

- Use the fonts only for these tests until A confirms release. Do not use them in real letters, reports, templates, letterheads or the live website.
- Do not change Word's AutoCorrect list or Outlook's default fonts.
- Do not edit or rename the font files.
- Uninstall the Hinted Test fonts after H1.
- If you cannot run a row, tell A and say why.
