# NSATS Clear: round 1 follow-up (missing tests and how to capture evidence)

**Release under test:** NSATS Clear release candidate 04, version 1.100: six styles, 234 characters. Use web test page 1.6 and Word test document 1.4. **This is a test release, not production approval.**

Round 1 results came in on 3 October 2026. They are a useful start but incomplete. This page lists what is still needed and how to capture it, so every result can be traced to the exact page, fonts and device.

## 1. Missing tests

A row is complete only when its automatic results, visual verdicts, versions and screenshots have all been sent. A self-reported "all pass" is not enough on its own.

| Row | Device and app | Status after round 1 | Still needed |
| --- | --- | --- | --- |
| W1 | Windows 11, Edge | Automatic checks reported passing | Everything in section 2.1 |
| W2 | Windows 11, Chrome | Automatic checks reported passing | Everything in section 2.1 |
| W3 | Windows 11 or Mac, Firefox | Automatic checks reported passing (Windows) | Everything in section 2.1 |
| W4 | Mac, Safari | **No result yet** | The full row |
| W5 | Mac, Chrome | **No result yet** | The full row |
| W6 | iPhone, Safari | **Open finding:** T3n "Accents typed two ways match" reported failing, also in Chrome and Firefox on the same iPhone | Section 2.1, plus section 2.2 |
| W7 | Android, Chrome | Automatic checks reported passing (Android 11 and 15) | Everything in section 2.1, including the phone model |
| E1 | Windows 11, Word (Microsoft 365 desktop) | **No Microsoft 365 result supplied.** A Word 2010 run was inconclusive: font installation and availability unconfirmed | The full row, with section 2.3 |
| E2 | Mac, Word | **No result yet** | The full row, with section 2.3 |
| E3 | Adobe Acrobat Reader (the E1 PDF) | **No result yet** | The full row |
| E4 | Mac Preview (the E2 PDF) | **No result yet** | The full row |
| E5 | Physical print | **No result yet** | The full row |
| E6 | Windows 11, Outlook (desktop) | **No result yet** | The full row |
| H1 | Windows 11, hinting comparison in Word | **No result yet** | The full row |
| Extra | LibreOffice (Windows, Ubuntu) | Inconclusive: LibreOffice reported the font as not available | Optional re-run, with section 2.3 |

How to run each row is in the tester guide (`TESTING.md`).

## 2. How to capture evidence

### 2.1 Every browser run (W1–W7)

1. Open the web test page for this release (version 1.6), in the browser itself, at 100% zoom.
2. Fill in **Your setup**, then wait for **Automatic checks** to finish.
3. Choose **Pass / Issue / Not sure** for each test sheet, T2 to T12. Add a note for anything other than Pass.
4. Press **Copy results** and paste the text into your private message to your NSATS contact. The public test page does not save or send results anywhere. It records the page version, which should read "RC04 hosted web test 1.6", and every check's detail. **Send this text, not a summary.**
5. Write down, from the browser's own About page and the system settings:
   - the browser version;
   - the device model;
   - the operating system version or build;
   - the address or file you opened.
6. Take a **full-page screenshot**, or several overlapping ones, and send it as a file. Don't paste it into a document.

### 2.2 iPhone and iPad (W6), for each browser

1. Send the **iOS version** (Settings › General › About) and each browser's version.
2. Send a screenshot of the **T3 "Every character" sheet**, including the four accent lines at the bottom: NFC above NFD, twice.

### 2.3 Word, Outlook, LibreOffice and other desktop apps (E1–E6, H1)

**If NSATS Clear is already installed (returning testers), capture the current state first.** Do this before removing, reinstalling or changing anything, so round 1 results can be traced:
1. **Where the installed files came from** and **how they were installed** (Install, or Install for all users; per user or system-wide).
2. **The SHA-256 hash of the installed `NSATSClear-Regular.ttf`**: Windows `certutil -hashfile <file> SHA256`; Mac `shasum -a 256 <file>`; Linux `sha256sum <file>`. Find the installed file as follows:
   - **Windows:** `C:\Windows\Fonts`, or `%LOCALAPPDATA%\Microsoft\Windows\Fonts` for a per-user install.
   - **Mac:** Font Book, then the font, then Show in Finder.
   - **Linux:** `~/.local/share/fonts`, or `fc-list | grep -i "NSATS Clear"`.
3. **The version** shown in the font's Properties or Font Book.
4. **Each application's name and exact version.**
5. **A screenshot of the font box** in each application, with the symbol line of the Word test document selected.

Send these to your NSATS contact. **Then**, before installing release candidate 04:
1. Remove the earlier NSATS Clear fonts.
2. Restart the computer.

**Install the six files from `fonts/ttf` in the test kit:**
- **Windows:** select them, right-click, then **Install for all users**.
- **Mac:** double-click each file, then Install Font.
- **Linux:** copy them to `~/.local/share/fonts`, then run `fc-cache -f`.

**Then record, for the newly installed fonts:**
1. **Where the files came from** (the test kit download, or the repository) and **how you installed them**.
2. **The version** shown in the font's Properties (Windows) or Font Book (Mac). It must read 1.100.
3. **The SHA-256 hash** of `NSATSClear-Regular.ttf`, because a version number alone cannot tell builds apart:
   - Windows: `certutil -hashfile NSATSClear-Regular.ttf SHA256`
   - Mac: `shasum -a 256 NSATSClear-Regular.ttf`
   - Linux: `sha256sum NSATSClear-Regular.ttf`

   The expected value for release candidate 04 is `7e589e3f6158c6a799b7bd003dc62349a0c0c507fe0a901e20762e0705fb2600`.
4. **The application name and exact version** (for example, Word: File › Account › About Word).
5. In the document, **a screenshot of the font box** with a line of NSATS Clear text selected, including the symbol line.
6. The saved file, the exported PDF and the completed results form (`testing/results-form.md`). Send them privately to your NSATS contact.

### 2.4 Plain-text paste into another app (optional)

When text is pasted as plain text (for example into Notepad), only the characters are carried, not the font: the receiving app shows them in its own font. This explanation covers plain-text pasting only. Pasting into a rich-text app such as Word may behave differently.

If a character seems to **change** after a plain-text paste (not just look different), send:
- the receiving app's font name;
- the character's code. For example, in Windows Word, put the cursor after the character and press Alt+X.

## 3. Sending results

- Send one message per row, with files named `NSATS Clear test - <row> - <your name> - <date>`.
- Send results, copied results text and screenshots privately, only to the NSATS contact who gave you this test kit. Nothing is saved or collected by the test pages themselves.
- Please don't use the fonts outside these tests, and remove them when you're done.

Untested so far, beyond the reports above:
- Word on Windows and Mac, including AutoCorrect/AutoFormat
- Windows DirectWrite/GDI
- macOS native applications
- iOS/Android
- W1–W7
- physical print
- hinted rendering
- reader studies
