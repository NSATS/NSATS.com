# NSATS Clear results form (E1–E6, H1)

Copy this form into your email to A and fill it in. Web rows (W1–W7) use the test page's own Save results or Copy results instead.

```text
Row: (E1 / E2 / E3 / E4 / E5 / E6 / H1)
Tester and date:
Device model:
Operating system and build:
App and version (Word / Acrobat / Preview / Outlook classic or new):
Editing language (Word only):
Printer model and quality setting (E5 only):
Display scale (H1 only):

AutoCorrect results (E1/E2): trigger -> result -> font shown -> code (Windows, Alt+X)
(c) ->
(r) ->
(tm) ->
1/2 ->
1/4 ->
3/4 ->
--> ->
<-- ->

Font version shown after installing (must be 1.100; earlier 1.000 fonts removed first? yes/no):
Every-character check (229 characters): any character in another font? (yes/no, which)
Western European text (Word section 9): accents placed and spaced well? narrow space in the French line? (yes/no, notes)
Six styles: real bold, SemiBold and italic? underlines OK? (yes/no, notes)
SemiBold in Word (E1/E2): NSATS Clear entries in the font list; what Ctrl+B / Cmd+B and Ctrl+I / Cmd+I did on SemiBold text:
Sizes and zero: 0 clear from O and 8 at 9 pt? (yes/no, notes)
Table figures aligned? (yes/no)
PDF fonts listed (E3/E4):
Copy/paste and search OK (E3/E4), including accented words such as Größe and Ação? (yes/no, notes)
Print (E5): small text clear? 0/O/8 distinct at 9 pt? (yes/no, notes)
Outlook (E6): what you saw / what the colleague saw:
H1: clearer family per size (8/9/10/11/12 pt), including SemiBold, and anything wrong:

Issues found (one per line): severity - what - where (style, size, characters)
```
