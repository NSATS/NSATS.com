# Windows hinting comparison fonts (H1 only)

These six files are the release candidate 04 fonts (version 1.100) with automatic hinting added by ttfautohint. They are renamed "NSATS Clear Hinted Test" (SemiBold: "NSATS Clear Hinted Test SemiBold") so that they can be installed beside the release fonts without clashing.

Use them only for the H1 comparison in [testing/TESTING.md](../../testing/TESTING.md). Never use them in documents, and uninstall them when H1 is done. The release fonts are in `fonts/ttf`.
