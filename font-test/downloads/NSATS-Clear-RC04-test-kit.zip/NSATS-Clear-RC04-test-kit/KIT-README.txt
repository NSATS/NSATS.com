NSATS Clear test kit: release candidate 04 (version 1.100)
==========================================================
Six styles (Regular, Italic, SemiBold, SemiBold Italic, Bold, Bold Italic), 234 characters.
This is a test release, not approval for production use. NSATS Clear is a modified version of IBM Plex Sans 3.005
under the SIL Open Font License 1.1 (OFL.txt) and is not affiliated with or endorsed by IBM.

Start with testing/ROUND-1-FOLLOW-UP.md (what is still needed and how to capture evidence), then testing/TESTING.md.
In TESTING.md, "this repository" means this kit, and "the hosted test page" means the web test page linked from the
page where you downloaded the kit.

Results are NOT saved or sent anywhere by the public web test page or this kit. Where TESTING.md says results "save
straight to A" or to press "Save results", that applies only to a private claude.ai page shared with you directly; it
does not apply here. Instead, press "Copy results" on the web test page and send the copied text, with your
screenshots and files, privately to the NSATS contact who gave you this kit.

If NSATS Clear is already installed from an earlier round, first record its provenance (where the files came from,
installation method, the installed file's SHA-256 hash, version, application versions and a font-box screenshot) before
removing or reinstalling anything. See section 2.3 of testing/ROUND-1-FOLLOW-UP.md.

fonts/ttf                              install these six for desktop tests (E1-E6)
fonts/woff2                            the same fonts for web use
fonts/windows-hinting-comparison-only  H1 only; never use in documents
testing/web-test                       the web test page (opens offline in a browser)
testing/word-test                      Word test document 1.4 and its reference PDF
SHA256SUMS.txt                         check with: shasum -a 256 -c SHA256SUMS.txt (Mac/Linux)
