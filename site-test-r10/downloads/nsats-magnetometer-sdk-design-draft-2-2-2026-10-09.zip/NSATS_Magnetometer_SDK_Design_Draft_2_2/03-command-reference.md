# Magnetometer SDK: command reference

**SDK design documentation.** Draft 2 · 9 October 2026

These logical operations form a software development kit (SDK) interface design. A future command utility or programming-language binding can expose them after the device protocol is defined. They are not released API signatures or actual magnetometer commands. Uppercase terms represent values supplied for a particular device or procedure.

## Session and acquisition

| Operation | Prerequisite | Intended result |
| --- | --- | --- |
| connect DEVICE_REFERENCE | A supported adapter and device reference. | Connection result, available identity and unauthenticated access state. |
| login | A live connection and specified authentication mechanism. | Confirmed access state and permissions, or an access failure. |
| describe | Sufficient access for device inspection. | Device/adapter versions, channel mapping, supported functions and active configuration. |
| read once channels=all | Authorised measurement access and an interpretable channel contract. | One acquisition with eight channel entries and their statuses. |
| read window channels=all | The above plus valid window and processing settings. | An acquisition window and separately identified processing results. |
| stream start channels=all | Supported continuous acquisition and defined rate/buffering settings. | Stream identifier and confirmed effective settings. |
| stream stop | An active stream. | Whether stopping was confirmed and the disposition of any final partial data. |
| logout | An authenticated session. | Access revocation outcome and local credential cleanup status. |
| disconnect | A connected or failed session. | Local connection closure and any unconfirmed equipment state. |

Stream delivery to the application, buffering and overflow handling remain to be defined in the implementation contract; **stream start channels=all** does not specify them.

The design rejects measurement or configuration requests when their required authorisation is absent. If the actual hardware has no authentication facility, the access model must be resolved explicitly rather than simulated as a successful hardware login.

## Digital signal processing (DSP) and averaging

| Operation | Purpose | Information returned |
| --- | --- | --- |
| dsp inspect PROFILE_REFERENCE | Inspect a documented processing profile before use. | Applicable signal type, parameters, input/output representations and execution location. |
| dsp select PROFILE_REFERENCE | Request the selected profile. | Accepted configuration or a reason for rejection; no silent parameter substitution. |
| average configure METHOD WINDOW_REFERENCE | Select an averaging policy for each channel. | Effective window, input stage, method parameters, validity rules and configuration reference. |

The illustrative **average configure METHOD WINDOW_REFERENCE** form leaves the input-stage and per-channel-scope parameters unspecified. The implementation contract must define how they are supplied.

Profile selection must not imply that every named method is supported. If a change takes effect only at a later sample boundary, report that boundary. Reset affected processing history when configuration, calibration or session continuity changes, according to the selected profile.

## Calibration

| Operation | Purpose | Information returned |
| --- | --- | --- |
| calibration inspect | Inspect existing calibration and available procedures. | Antenna and DSP signal-source records, scope and applicability. |
| calibration prepare TARGET PROCEDURE_REFERENCE | Check requirements for a specific calibration. | Plan reference, affected channels or sources, required reference and acquisition impact. |
| calibration run PLAN_REFERENCE | Carry out a supported prepared procedure with suitable authority. | Progress and a candidate calibration record, or failure/unavailable status. |
| calibration apply RECORD_REFERENCE | Explicitly request application of a reviewed candidate. | Confirmation, scope, persistence and effective configuration revision. |

TARGET identifies antenna channels or a DSP signal source; the two must not be conflated. Producing a candidate record does not silently commit it to the hardware. Restoring an earlier calibration requires a device-supported recovery procedure; no universal rollback command is promised.

## Radio equipment self-tests

| Operation | Purpose | Information returned |
| --- | --- | --- |
| selftest list | Discover or inspect documented available equipment tests. | Test scope, prerequisites and whether measurement or a signal source is affected. |
| selftest run TEST_REFERENCE | Request one permitted, supported test. | Operation status and per-check results from the defined test procedure. |

A missing capability is reported as unsupported or unavailable. It is never substituted with an SDK-only check labelled as a successful radio equipment test.

## Result conventions

Each operation should identify the request, device, session and configuration concerned. Distinguish operation completion from the result of the task: a self-test command can complete successfully while one equipment check fails.

Useful design-level failure categories are not connected, authentication required, authentication rejected, access denied, unsupported operation, invalid configuration, missing calibration, timeout, partial acquisition, invalid sample and outcome unknown. A timeout during an operation that changes hardware is reported as outcome unknown until reconciled; timeout alone does not confirm that the change failed or stopped. Exact error codes and wire messages belong to the implementation contract.

After a communication loss during calibration, source activation or another hardware change, do not automatically repeat a command whose effect is unknown. Use **describe** to inspect the active configuration, **calibration inspect** for calibration records and **selftest list** for test scope and prerequisites. These are inspection routes, not guaranteed operation-status readback; the hardware contract must define how to reconcile the state through the device’s documented recovery path. Retries of read requests also need identifiers so duplicate responses are not counted twice.

See the [equipment guide](04-processing-and-equipment-guide.md) for processing and maintenance semantics.
