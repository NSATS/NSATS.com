# Magnetometer SDK design documentation

**SDK design documentation.** Draft 2 · 9 October 2026

These documents describe a software development kit (SDK) interface design for a custom eight-antenna magnetometer: connection and device login, acquisition from eight antennas, digital signal processing (DSP) signal isolation, antenna and DSP signal-source calibration, radio equipment self-tests and advanced averaging.

Commands, response structures and numerical examples are illustrative. No executable software, hardware adapter, measured data or tested device connection is included. Hardware protocol, authentication, data representation, units, timing and processing location remain to be specified.

These documents concern acquisition and equipment operation. They do not define how positioning is computed or present the custom magnetometer as an NSATS product. Device authentication is separate from MyNSATS; the website does not connect to, authenticate or control hardware.

## Reading order

1. [Magnetometer SDK: developer walkthrough](02-developer-walkthrough.md)
2. [Magnetometer SDK: hardware and data interface](01-hardware-and-data-interface.md)
3. [Magnetometer SDK: command reference](03-command-reference.md)
4. [Magnetometer SDK: processing and equipment](04-processing-and-equipment-guide.md)
5. [Magnetometer SDK: responses and examples](05-responses-and-examples.md)

Start with the walkthrough. File numbers retain the Draft 1 identities; this list sets the reading order.

## Distribution notice

You may share this documentation unchanged within your organisation for evaluation, retaining attribution, its date and Draft 2 status. External redistribution requires NSATS’s written permission.
