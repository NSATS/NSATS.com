# Magnetometer SDK: responses and examples

**SDK design documentation.** Draft 2 · 9 October 2026

The following records describe how the software development kit (SDK) interface design communicates results. They are invented structural examples, not messages captured from a device, released schemas or measured magnetic data. All channel aliases and references are illustrative.

## Login and first acquisition

| Request | Illustrative response contents |
| --- | --- |
| connect DEVICE_REFERENCE | Communication established; device reference EXAMPLE_DEVICE; access state not authenticated. |
| login | Authentication accepted by the example scenario; permitted operations identified by the access mechanism. No credentials are displayed. |
| describe | Eight channel aliases A1–A8; actual mapping, units, representation and timing supplied by a future device description. |
| read once channels=all | Acquisition reference EXAMPLE_ACQUISITION; eight channel entries; each entry has its own sample and quality status. |

The success path assumes a future adapter, valid credentials and a defined device description. It does not establish that this hardware currently implements login. If interpretation metadata is missing in real use, the SDK must not label a raw payload as a valid physical measurement.

## Eight-channel response structure

| Channel alias | Measurement payload | Representation and units | Status in this document |
| --- | --- | --- | --- |
| A1 | Not supplied | Await hardware specification | Illustrative slot only |
| A2 | Not supplied | Await hardware specification | Illustrative slot only |
| A3 | Not supplied | Await hardware specification | Illustrative slot only |
| A4 | Not supplied | Await hardware specification | Illustrative slot only |
| A5 | Not supplied | Await hardware specification | Illustrative slot only |
| A6 | Not supplied | Await hardware specification | Illustrative slot only |
| A7 | Not supplied | Await hardware specification | Illustrative slot only |
| A8 | Not supplied | Await hardware specification | Illustrative slot only |

The table deliberately leaves measurements unfilled. In a real partial acquisition, for example, an absent A8 result would have an unavailable status and no fabricated payload. The record would remain partial even if A1–A7 were valid. An absent sample time would remain unknown rather than being copied from the computer's receipt time.

## Averaging arithmetic

This separate educational example assumes scalar observations in arbitrary example units. It does not choose the actual antenna data type, sampling rate, units or an SDK default. The policy is a four-observation window with at least three included observations, averaging each channel separately.

| Channel | Four example observations | Included | Rejected | Missing | Result |
| --- | --- | ---: | ---: | ---: | --- |
| A1 | 10, 12, invalid, 14 | 3 | 1 | 0 | Mean 12 |
| A2 | 20, 22, 24, 26 | 4 | 0 | 0 | Mean 23 |
| A3 | 30, missing, missing, 36 | 2 | 0 | 2 | Insufficient data; no mean |
| A4 | 40, 42, 44, 46 | 4 | 0 | 0 | Mean 43 |
| A5 | 50, 52, 54, 56 | 4 | 0 | 0 | Mean 53 |
| A6 | 60, 62, 64, 66 | 4 | 0 | 0 | Mean 63 |
| A7 | 70, 72, 74, 76 | 4 | 0 | 0 | Mean 73 |
| A8 | 80, 82, 84, 86 | 4 | 0 | 0 | Mean 83 |

For A1, (10 + 12 + 14) / 3 = 12. The invalid observation is not replaced with zero. Its fraction of included observations is 3/4; that fraction describes this example window, not measurement accuracy or time coverage. For A3, averaging the two available numbers would violate the example’s minimum of three included observations.

## Calibration example

An antenna calibration produces candidate record EXAMPLE_ANTENNA_CAL. The application displays the affected channels, reference and procedure result. It does not apply the candidate merely because the procedure finished. A separate apply request needs confirmed scope and authority.

A digital signal processing (DSP) signal-source calibration produces a different candidate record, EXAMPLE_SOURCE_CAL. Both references are associated with processed results when both are applicable. No calibration coefficients or acceptance limits are fabricated in this example.

## Self-test example

A supported test can return “operation completed” with one check failed and another not run. The application presents those outcomes individually. It must not interpret successful command transport as “radio equipment passed”. Actual test names, limits and results await the equipment specification.

## Failure examples

| Situation | Intended response |
| --- | --- |
| No device connection | Explain that a connection is required; supply no measurement result. |
| Login rejected | Keep access unauthenticated and provide no protected operation result. |
| Requested DSP profile unavailable | Report unsupported profile; do not substitute a different filter silently. |
| Calibration or units unknown | Preserve unknown status; do not label the reading as a calibrated physical quantity. |
| One channel missing | Return a partial acquisition with that channel marked unavailable. |
| Too few included observations | Return insufficient data for the affected average. |
| Connection lost during calibration application | Report outcome unknown; inspect the actual state after reconnection with describe and calibration inspect, following the hardware contract’s recovery procedure before retrying. |
| Connection lost during streaming | Mark subsequent data unavailable, preserve received records with their provenance and identify any known gap. |

These are result semantics, not assigned protocol error codes. See the [command reference](03-command-reference.md) for operation prerequisites.
