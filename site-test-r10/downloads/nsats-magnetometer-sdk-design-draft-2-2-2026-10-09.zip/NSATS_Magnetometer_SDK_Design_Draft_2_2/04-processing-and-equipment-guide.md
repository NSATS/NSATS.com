# Magnetometer SDK: processing and equipment

**SDK design documentation.** Draft 2 · 9 October 2026

The software development kit (SDK) design separates raw acquisition, signal processing and equipment maintenance. This makes it possible to identify what was read, which processing was applied and which calibration was active. The operations below are design requirements, not a statement of tested device capabilities.

## Read eight antenna inputs

Keep A1–A8 separately identifiable throughout acquisition and processing. Each channel retains its own representation, units and status. Where processing combines channels, the combination must be an explicitly defined operation with known geometry, alignment and timing; it is not the default averaging operation.

Retain the raw input where the device supplies it. If only an already processed output is available, identify that stage and do not relabel it as raw. Missing channels and uncertain timing remain visible in subsequent results.

## Isolate a signal with digital signal processing (DSP)

Digital signal processing needs a defined signal of interest and input representation. Before selecting a method, describe what should be preserved and what should be suppressed. A frequency-domain profile also needs the relevant sampling and frequency information. No frequency band, filter coefficients or isolation performance is specified here.

Each profile should describe its applicable channels, input stage, configurable parameters, output meaning, execution location and any delay or initial settling interval. Record its revision with the output. Processing order, including whether calibration precedes or follows a stage, belongs to that profile rather than a universal pipeline.

The SDK should reject incompatible settings and report effective settings after an accepted change. Signal isolation must be assessed against defined reference inputs and criteria; a cleaner-looking trace alone is not evidence that the intended signal has been recovered.

## Calibrate antenna channels

An antenna calibration procedure relates a channel's response to an identified reference under stated conditions. The procedure must specify the reference, physical arrangement, input observations, correction model and acceptance criteria before it can be executed.

The design workflow is to inspect existing calibration, prepare the procedure, obtain its measurements, review a candidate record and explicitly apply that record. Keep the previous record identifiable. The active configuration must report which calibration applies to each channel and when a new record becomes effective.

A calibration record should identify the device and channel mapping, procedure version, reference source, conditions, results and applicability. Do not invent calibration dates, validity periods or pass limits. An absent or inapplicable record must remain distinguishable from a calibrated result.

## Calibrate DSP signal sources

Treat signal-source calibration separately from antenna-response calibration. First identify what the source is: a hardware reference, an injected test signal, a digital reference or another source specified by the designer.

The procedure must identify which source parameters it evaluates and how its reference is established. Do not assume that the equipment can generate or inject a signal merely because the SDK has a calibration operation. Source control, signal routing and the effect on normal acquisition need explicit device support.

The candidate record identifies the source and its settings, procedure, reference and acceptance result. A source calibration cannot stand in for an antenna calibration. Results dependent on both need both references.

## Run radio equipment self-tests

Begin with the hardware's documented test catalogue. A test record states which equipment it checks, its prerequisites, acquisition impact and whether it activates a source or changes routing. The SDK exposes only tests the hardware and adapter can actually perform.

The report distinguishes pass, fail, not run, unsupported and inconclusive outcomes for each check. Pass/fail criteria come from the approved test definition. A software connection check establishes communication only; it is not evidence that the radio path passed a self-test.

Before returning to acquisition, inspect the resulting device state and identify any setting that was not restored. A timeout during a test is reported as outcome unknown until reconciled, not an equipment pass or a completed stop. The same rule applies to any timeout during an operation that changes hardware. Use **describe** for active configuration, **calibration inspect** for calibration records and **selftest list** for test scope and prerequisites. These inspections do not guarantee operation-status readback; the hardware contract must define the recovery steps and evidence needed to resolve the outcome.

## Advanced averaging

The averaging interface design works over time within each channel. It names the input stage, window, method and minimum usable observations, and reports how much data contributed to the result. The options below are candidates for the design, not confirmed device features.

| Candidate method | Purpose and configuration |
| --- | --- |
| Windowed arithmetic mean | Equal contribution from valid observations in a defined sample-count or time window. |
| Weighted mean | A stated weighting rule, recorded with the result; reject a zero total weight. |
| Exponential smoothing | A parameter-controlled result that gives progressively less weight to older observations; initialise and reset its history explicitly. |
| Median or trimmed summary | An optional robust summary for a justified signal model; identify it by its actual method rather than calling every result a mean. |

NIST distinguishes equal-weight moving averages from exponential smoothing and describes why a median and mean respond differently to extreme observations. These general methods do not establish magnetometer-specific performance. [NIST smoothing methods](https://www.itl.nist.gov/div898/handbook/pmc/section4/pmc43.htm) · [NIST measures of location](https://www.itl.nist.gov/div898/handbook/eda/section3/eda351.htm)

Exclude samples that the selected policy identifies as unusable, retain the exclusion reason and report included, rejected and missing counts. If the valid-count requirement is not met, return an insufficient-data result instead of a numeric average. For time windows, also report actual coverage and gaps; a sample count alone cannot establish the elapsed span.

Do not silently discard unusual but valid observations. A real change in the magnetic input may be the event the application needs to observe. Any statistical exclusion rule needs an explicit profile and preserved source observations. [NIST outlier guidance](https://www.itl.nist.gov/div898/handbook/eda/section3/eda35h.htm)

Do not average incompatible representations, differently calibrated values or unaligned channels into one result. When a profile or calibration changes, close or discard the affected window according to a declared policy and start a new history. Smoothing must be assessed for both stability and preservation of the changes relevant to the application; no accuracy multiplier is claimed.
