# Magnetometer SDK: developer walkthrough

**SDK design documentation.** Draft 2 · 9 October 2026

This walkthrough describes the software development kit (SDK) workflow of connecting to attached hardware, logging in and reading its eight antenna channels. The command forms illustrate the design; this edition supplies no executable commands for a device.

## Connect to the intended device

Select a device reference using the connection method supported by its adapter. The reference might ultimately identify a port or a network endpoint, but this edition chooses neither.

Uppercase terms stand for values supplied for a particular device or procedure; they are not literal device identifiers or credentials.

Example request: **connect DEVICE_REFERENCE**.

Expected response information: whether communication was established, the identity available from the device, and the current access state. A connected state alone does not grant permission to read or change equipment.

## Log in

Example request: **login**.

The interface design prompts through the device's supported authentication mechanism. It reports authenticated access only when that mechanism confirms it. It should explain access failure without revealing credentials. If the required authentication protocol is unavailable or not implemented, the walkthrough stops here for real hardware.

Device authentication belongs to the magnetometer and is separate from MyNSATS sign-in. The website does not connect to, authenticate or control hardware.

## Inspect the configuration

Example request: **describe**.

Inspect the eight-channel mapping, data representation, timing information, supported operations and active configuration. Check which calibration records and processing profiles are applicable. Missing metadata stays explicit; it must not be replaced by guessed units or assumed channel synchronisation.

## Obtain the first reading

Example request: **read once channels=all**.

The intended result contains one acquisition with a status for each of A1–A8. A valid reading includes its value or sample payload and the information needed to interpret it. A partial acquisition identifies the missing channels. The [response example](05-responses-and-examples.md) shows the structure without inventing physical readings.

## Continuous acquisition

Where the device and adapter support continuous acquisition, the illustrative request is **stream start channels=all**. How stream records reach the application, including delivery, buffering and overflow handling, remains to be defined in the implementation contract. Inspect confirmed effective settings before treating a stream as active.

## Select processing

For a device and adapter that support a documented digital signal processing (DSP) profile, inspect it before selecting it.

Example requests: **dsp inspect PROFILE_REFERENCE**, followed by **dsp select PROFILE_REFERENCE**.

The response identifies the processing location, parameters and effective configuration revision. The signal of interest and compatible sample representation must be defined before a profile can be applied. Preserve access to the raw input or identify explicitly when hardware supplies only processed data.

## Obtain an averaged result

Example request: **average configure METHOD WINDOW_REFERENCE**.

Choose an approved input stage and per-channel averaging method. The illustrative command form does not specify how the input stage or per-channel scope is supplied; those parameters remain open design points. Inspect the effective settings, including the window, minimum valid observations and handling of gaps. Then request **read window channels=all** to acquire the configured window and retrieve the available raw, DSP and averaged results separately.

The window's duration cannot be inferred from a sample count until timing is known. An averaged result must state included, rejected and missing observation counts. It must not merge A1–A8 into a single value by default.

## Calibrate or test as a separate task

Use **calibration inspect** or **selftest list** to inspect the relevant procedures. Calibration and self-tests are not automatic login steps. A procedure may require a reference source, a particular equipment configuration or a pause in acquisition; these conditions must be known before it runs.

Follow the [equipment guide](04-processing-and-equipment-guide.md) to prepare a procedure, review its scope and inspect its result. Successful login or data receipt is not a radio self-test.

## Disconnect

If continuous acquisition was started, request **stream stop** and check its outcome. Then request **logout** and **disconnect**.

The application closes its local session and distinguishes confirmed hardware changes from actions it could not confirm. A disconnected session does not by itself prove that equipment stopped acquiring or that a hardware signal source was switched off. On reconnection, authenticate as required and inspect the current state again.
