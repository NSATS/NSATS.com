# Print and PDF

## Embedding
All six fonts have OS/2 fsType 0 (installable embedding), and the SIL OFL permits embedding, so PDFs can carry the fonts. The OFL's conditions apply to the fonts; they do not extend to documents or PDFs made with them.

| Route | How | Kerning and accent positioning |
|---|---|---|
| Word, Pages, Keynote | Export/Save as PDF | Pages and Keynote applied the kerning in the 1.202 Mac tests; Word applies it only with "Kerning for fonts" on |
| Browser / HTML | `html/print.css` + `html/example.html`; Chrome "Save as PDF", Playwright, Puppeteer, WeasyPrint | applied by browsers that support OpenType features; the example was run with Chromium on Linux |
| LaTeX | `latex/nsats-sans.sty`, compile with XeLaTeX or LuaLaTeX | applied by fontspec's default features; the example was run on Linux |
| Node.js | `node-pdfkit/example.js` (PDFKit) | kerning applied by PDFKit; the example was run on Linux |
| Python | `python-reportlab/example.py` (ReportLab) | **not** applied — use composed (NFC) text; prefer the routes above for final typography |
| Adobe InDesign / Illustrator | File > Export > Adobe PDF (Print) | Adobe documents that Metrics kerning uses the font's pairs; not tested with NSATS Sans |

## Checking a PDF
- Adobe Acrobat / Reader: File > Properties > Fonts — every NSATS face should be listed as "Embedded Subset".
- Command line: `pdffonts file.pdf` (Poppler) — the `emb` column should read `yes` for each NSATSSans face.
- Search the PDF for an accented word (for example "Łódź") to check the text layer.

## Professional print
- Send PDF/X (for example PDF/X-4) with fonts embedded; NSATS Sans needs no special handling.
- Proof at 100 % (no "fit to page") on the target printer and paper, especially for small text: check 7–9 pt figures, the dotted zero against O and 8, and accents.
- Converting text to outlines is allowed but removes searchable text; keep live text where you can.
- There is no "300 dpi font": the outlines are vectors and print at the printer's resolution.

## Known limitations
- **Scope.** These limitations were measured on a Mac with the NSATS Clear 1.202 fonts (macOS 26.6.2, recorded application versions). NSATS Sans 1.203 has identical glyphs, spacing, kerning and line metrics, so they apply unchanged; 1.203 itself was not re-measured in these applications.
- **Which text.** Stacked accents outside the 388-character set: a capital letter that already carries an accent followed by an extra combining accent (for example Ê followed by U+0301), and Å or Ů followed by an extra combining ring.
- **Clipping in TextEdit (visual).** At its default line height, TextEdit cut off the extra marks on these capitals in all six styles, and the extra ring on Bold Å and Ů. Pages and Word enlarged the line and showed every mark.
- **Overlap in Keynote (visual).** With 11 pt text on 14 pt lines, the extra marks on these capitals overlapped the ogoneks (ą, ę) on the line above, in all six styles. Whether more line spacing avoids this was not tested.
- **Two encoded letters (visual exception).** On the first line of a TextEdit page the clipping boundary is lower: in the measured TextEdit PDF it cut 0.06 pt or less from Bold Italic Å and SemiBold Italic ĥ, which was not visible at the sizes tested.
- **Coverage.** Clipping of ordinary (encoded) text in other applications, line spacings and layouts has not been verified.
- **Copying text from PDFs (a separate problem).** The extra marks use glyphs that have no character code of their own. In the tested PDFs exported from Pages, Keynote, TextEdit and Word, these glyphs had no ToUnicode entries, and in copies of those PDFs saved from Preview the five tested stacks became unrelated ASCII characters. PDFium recovered the five tested stacks from the Pages, Keynote and TextEdit PDFs, which carry ActualText, but not from the Word PDF, which does not. These results apply to the tested files and text only; other PDF readers and producers were not tested.
- **Ordinary accented text.** The tested ordinary accented words showed no comparable visual problem and copied correctly from the tested PDFs (allowing for composed and decomposed forms); exact code-point preservation and search in every application are not claimed.
- Physical print has not been verified.

## Tested in this kit
The ReportLab, PDFKit, XeLaTeX, LuaLaTeX and Chromium HTML-to-PDF examples were run on Linux; each PDF embeds NSATS Sans (checked with `pdffonts`). No PDF from this kit was printed.
