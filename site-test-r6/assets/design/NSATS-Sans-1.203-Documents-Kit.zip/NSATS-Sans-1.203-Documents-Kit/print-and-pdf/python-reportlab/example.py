"""Create a PDF with NSATS Sans using ReportLab (pip install reportlab).
Run from this folder:  python3 example.py   -> nsats-sans-reportlab.pdf
ReportLab embeds the fonts but does not apply OpenType kerning or mark positioning, so write accented text
in composed (NFC) form, e.g. unicodedata.normalize("NFC", text). For full typography use the HTML or LaTeX routes."""
import os, unicodedata
from reportlab.lib.pagesizes import A4
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.fonts import addMapping
from reportlab.pdfgen import canvas
FONTS = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', 'fonts', 'ttf')
for style in ('Regular', 'Italic', 'SemiBold', 'SemiBoldItalic', 'Bold', 'BoldItalic'):
    pdfmetrics.registerFont(TTFont(f'NSATSSans-{style}', os.path.join(FONTS, f'NSATSSans-{style}.ttf')))
pdfmetrics.registerFontFamily('NSATSSans', normal='NSATSSans-Regular', bold='NSATSSans-Bold',
                              italic='NSATSSans-Italic', boldItalic='NSATSSans-BoldItalic')
c = canvas.Canvas('nsats-sans-reportlab.pdf', pagesize=A4, initialFontName='NSATSSans-Regular')
y = 780
for style, size in (('SemiBold', 24), ('Regular', 12), ('Italic', 12), ('Bold', 12), ('BoldItalic', 12), ('SemiBoldItalic', 12)):
    c.setFont(f'NSATSSans-{style}', size)
    text = 'NSATS Sans ' + style if size > 12 else unicodedata.normalize('NFC', f'{style}: Clear communication · AED 12,450.00 · Łódź · Žluťoučký · İstanbul')
    c.drawString(72, y, text); y -= size * 2
c.save()
print('wrote nsats-sans-reportlab.pdf')
