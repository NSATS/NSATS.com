// Create a PDF with NSATS Sans using PDFKit (npm install pdfkit). Run: node example.js -> nsats-sans-pdfkit.pdf
// PDFKit embeds subsets of the fonts and applies the font's kerning.
const fs = require('fs');
const path = require('path');
const PDFDocument = require('pdfkit');
const FONTS = path.join(__dirname, '..', '..', 'fonts', 'ttf');
const doc = new PDFDocument({ size: 'A4', margin: 72 });
doc.pipe(fs.createWriteStream('nsats-sans-pdfkit.pdf'));
for (const style of ['Regular', 'Italic', 'SemiBold', 'SemiBoldItalic', 'Bold', 'BoldItalic']) {
  doc.registerFont(`NSATS Sans ${style}`, path.join(FONTS, `NSATSSans-${style}.ttf`));
}
doc.font('NSATS Sans SemiBold').fontSize(24).text('NSATS Sans with PDFKit');
doc.moveDown();
for (const style of ['Regular', 'Italic', 'Bold', 'BoldItalic']) {
  doc.font(`NSATS Sans ${style}`).fontSize(12).text(`${style}: Clear communication · AED 12,450.00 · Łódź · Žluťoučký · İstanbul`);
}
doc.end();
console.log('wrote nsats-sans-pdfkit.pdf');
