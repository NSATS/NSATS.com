# NSATS Sans 1.203 — font facts

| Property | Value |
|---|---|
| Version | 1.203 (owner-approved 7 October 2026) |
| Format | TrueType (`fonts/ttf`, unhinted); WOFF2 for the web in the Web Kit |
| Characters | 388 encoded, 431 glyphs per style |
| Units per em | 1000 |
| Ascender / descender (hhea) | 1025 / -275, line gap 0 |
| Cap height / x-height | 698 / 538 |
| Italic angle | 11° (designed slants, real italic fonts) |
| Embedding | fsType 0 (installable) |
| Code pages | Windows 1252, 1250, 1254, 1257 and Mac Roman |
| OpenType features | kern, mark, mkmk (positioning); ccmp, pnum, tnum (substitution) |
| Figures | tabular by default; `pnum` gives proportional figures |
| Licence | SIL Open Font License 1.1; modified from IBM Plex Sans 3.005 |

## Styles

| Style | Menu family (Office) | Office style | PostScript name | Weight | CSS style |
|---|---|---|---|---|---|
| Regular | NSATS Sans | Regular | NSATSSans-Regular | 400 | normal |
| Italic | NSATS Sans | Italic | NSATSSans-Italic | 400 | italic |
| SemiBold | NSATS Sans SemiBold | Regular | NSATSSans-SemiBold | 600 | normal |
| SemiBoldItalic | NSATS Sans SemiBold | Italic | NSATSSans-SemiBoldItalic | 600 | italic |
| Bold | NSATS Sans | Bold | NSATSSans-Bold | 700 | normal |
| BoldItalic | NSATS Sans | Bold Italic | NSATSSans-BoldItalic | 700 | italic |

The Office columns follow the font's name IDs 1 and 2 (observed in Word for Mac with the 1.202 fonts). Applications that group by typographic family (name ID 16) can list all six under **NSATS Sans**; grouping varies by application.

## Coverage
ASCII, Latin-1, Windows-1252, Latin Extended-A, Mac Roman (except the Apple logo) and 15 combining accents. Supports English, Western European languages (including Icelandic), Central European (Czech, Slovak, Polish, Hungarian, Croatian, Slovenian), Baltic (Lithuanian, Latvian, Estonian), Turkish, Maltese, Esperanto and Welsh. Not included: Romanian comma-below letters (Ș ș Ț ț), Vietnamese, Greek, Cyrillic. Native-speaker review has not been done. Full list: `CHARACTER-SET.txt`.
