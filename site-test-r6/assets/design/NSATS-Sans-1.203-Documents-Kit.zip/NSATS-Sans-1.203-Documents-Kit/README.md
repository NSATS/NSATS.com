# NSATS Sans 1.203 — Documents, Print and Design Kit

Everything needed to use NSATS Sans in documents, presentations, PDFs, print and design applications: the six desktop fonts, install guides and scripts, Word and PowerPoint templates, Office theme fonts, PDF and print examples for four toolchains, design-application guidance, a specimen and reference sheets.

NSATS Sans is the NSATS typeface (formerly NSATS Clear), a modified version of IBM Plex Sans 3.005. Licence: SIL Open Font License 1.1 (`OFL.txt`). For websites use the separate **Web Kit**.

## Contents

| Path | What it is |
|---|---|
| `fonts/ttf/` | NSATSSans-Regular, -Italic, -SemiBold, -SemiBoldItalic, -Bold, -BoldItalic (`.ttf`, unhinted) |
| `install/` | `INSTALL.md` (macOS, Windows, Linux, mobile notes) and per-user install scripts for macOS, Windows and Linux |
| `office/` | Word template (`.dotx`) and sample (`.docx`), PowerPoint template (`.potx`), Office theme-fonts file, `OFFICE.md` (Word, PowerPoint, Excel, Pages/Keynote/Numbers, Google Docs) |
| `print-and-pdf/` | `PRINT-AND-PDF.md`; examples for HTML-to-PDF (Chrome/Playwright/WeasyPrint), LaTeX (XeLaTeX/LuaLaTeX), Node.js (PDFKit) and Python (ReportLab) |
| `design-apps/DESIGN-APPS.md` | Figma, Adobe InDesign/Illustrator/Photoshop, Affinity, Sketch, Canva, Apple and Google apps |
| `reference/` | `NSATS-Sans-1.203-Specimen.pdf` (and its `specimen.html`), `FONT-FACTS.md`, `CHARACTER-SET.txt` |
| `web-fonts.css` | `@font-face` rules for the TTFs, used by the HTML print example and the specimen |
| `OFL.txt`, `FONTLOG.txt` | licence and history |

## Quick start
1. Install the fonts (`install/INSTALL.md`).
2. Word: open `office/NSATS-Sans-Word-Template.dotx` — headings in NSATS Sans SemiBold, text in NSATS Sans, kerning on.
3. PowerPoint: open `office/NSATS-Sans-PowerPoint-Template.potx`.
4. PDF from code: see `print-and-pdf/PRINT-AND-PDF.md`.

## Names in menus
| Face | Microsoft Office (four-style menus) | Applications that group by typographic family (varies by app) | CSS |
|---|---|---|---|
| Regular | NSATS Sans | NSATS Sans – Regular | 400 normal |
| Italic | NSATS Sans (italic) | NSATS Sans – Italic | 400 italic |
| SemiBold | **NSATS Sans SemiBold** | NSATS Sans – SemiBold | 600 normal |
| SemiBold Italic | **NSATS Sans SemiBold** (italic) | NSATS Sans – SemiBold Italic | 600 italic |
| Bold | NSATS Sans (bold) | NSATS Sans – Bold | 700 normal |
| Bold Italic | NSATS Sans (bold italic) | NSATS Sans – Bold Italic | 700 italic |

## Important notes
- **Word kerning:** turn on "Kerning for fonts" (1 pt and above) — the templates already do. Without it the spacing pairs are not applied.
- **Converting older documents:** documents set in NSATS Clear keep using NSATS Clear. Re-select NSATS Sans, or in Pages/Keynote use Format > Font > Replace Fonts.
- **Coverage:** 388 characters (Western, Central European, Baltic, Turkish, Maltese, Esperanto, Welsh). Not included: Romanian comma-below letters, Vietnamese, Greek, Cyrillic.
- **Known limitations** (stacked accents outside the character set: clipping in TextEdit, overlap in Keynote, and a separate PDF-copying problem; measured with the 1.202 fonts) and untested platforms are listed in `print-and-pdf/PRINT-AND-PDF.md` and the release notes.

## What was tested for this kit
On Linux only: the Word and PowerPoint files pass an Office schema validator and render in NSATS Sans in LibreOffice (structural checks, not Microsoft Office); the ReportLab, PDFKit, XeLaTeX, LuaLaTeX and Chromium HTML examples produce PDFs with NSATS Sans embedded; the Linux install script installs all six fonts. Separately, the fonts' design (as NSATS Clear 1.202, identical glyphs and spacing) was tested natively on a Mac in Word, Pages, Keynote, TextEdit and Preview. Not tested with this kit: Microsoft Office itself, Windows (including the PowerShell script), iPhone/iPad, Android, Adobe and other design applications, physical print.

## Licence
SIL Open Font License 1.1: you may use, copy, embed, modify and redistribute the fonts; keep `OFL.txt` with them; do not sell the fonts by themselves; do not use "Plex" in the name of a modified version or IBM's name to promote it. The licence's conditions apply to the fonts; they do not extend to documents, presentations or PDFs made with them.

## Integrity
`SHA256SUMS.txt` lists every file in the kit except itself. Check with `shasum -a 256 -c SHA256SUMS.txt`.
