# Installing NSATS Sans 1.203

Install the six files in `fonts/ttf/` (Regular, Italic, SemiBold, SemiBold Italic, Bold, Bold Italic). Install only one version of NSATS Sans at a time. NSATS Sans can be installed alongside the older NSATS Clear (different names); documents set in NSATS Clear keep using it until you re-select NSATS Sans.

## macOS
- **Font Book:** double-click each `.ttf` (or drag all six onto Font Book) and click Install.
- **Script (current user):** `sh install/install-macos.sh` copies the fonts to `~/Library/Fonts`.
- Quit and reopen applications afterwards.

## Windows 10/11
- **Explorer:** select the six `.ttf` files, right-click, choose **Install** (current user) or **Install for all users** (needs administrator rights).
- **Script (current user):** `powershell -ExecutionPolicy Bypass -File .\install\install-windows.ps1` (written on a Mac; not yet run on Windows).
- Restart Word, PowerPoint and browsers afterwards.

## Linux
- `sh install/install-linux.sh` copies the fonts to `~/.local/share/fonts/nsats-sans` and refreshes the font cache (`fc-cache`). Tested on Linux.

## iPhone and iPad
iOS and iPadOS do not install a font file when you open it. Custom fonts are normally added through an app that offers font installation or through a configuration profile (for example from an organisation's device management); which apps can then use them depends on the app. Not tested with NSATS Sans.

## Android
Android has no standard way for users to add fonts for the whole system; some device makers provide their own font tools, and apps can bundle fonts. Not tested with NSATS Sans.

## Check the installation
- macOS: Font Book should list the six NSATS Sans faces, version 1.203.
- Windows: Settings > Personalization > Fonts should list NSATS Sans (not tested).
- Word: the menu should list **NSATS Sans** (Regular, Italic, Bold, Bold Italic) and **NSATS Sans SemiBold** (SemiBold, SemiBold Italic). This grouping comes from the font names and was observed in Word for Mac with the 1.202 fonts (then named NSATS Clear); Word for Windows and PowerPoint were not tested.

## Uninstall
Delete the `NSATSSans-*.ttf` files from the folder they were copied to (macOS `~/Library/Fonts`; Windows Settings > Fonts > NSATS Sans > Uninstall; Linux `~/.local/share/fonts/nsats-sans` then `fc-cache -f`).
