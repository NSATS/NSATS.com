#!/bin/sh
# Install NSATS Sans for the current Linux user and refresh the font cache.
set -e
SRC="$(cd "$(dirname "$0")/../fonts/ttf" && pwd)"
DEST="${XDG_DATA_HOME:-$HOME/.local/share}/fonts/nsats-sans"
mkdir -p "$DEST"
cp -f "$SRC"/NSATSSans-*.ttf "$DEST/"
fc-cache -f "$DEST" >/dev/null 2>&1 || fc-cache -f
fc-list | grep -i "NSATS Sans" || echo "Fonts copied to $DEST; fc-list did not list them yet."
