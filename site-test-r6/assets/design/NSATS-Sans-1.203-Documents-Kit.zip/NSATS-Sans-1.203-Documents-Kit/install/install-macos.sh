#!/bin/sh
# Install NSATS Sans for the current macOS user (no administrator rights needed).
set -e
SRC="$(cd "$(dirname "$0")/../fonts/ttf" && pwd)"
DEST="$HOME/Library/Fonts"
mkdir -p "$DEST"
for f in "$SRC"/NSATSSans-*.ttf; do
  cp -f "$f" "$DEST/"
  echo "Installed $(basename "$f")"
done
echo "Done. Quit and reopen applications to see NSATS Sans."
