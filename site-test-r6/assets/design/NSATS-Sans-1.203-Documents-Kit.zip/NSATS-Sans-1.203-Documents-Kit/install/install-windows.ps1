# Install NSATS Sans for the current Windows user (Windows 10 1809 or later; no administrator rights needed).
# Usage (PowerShell):  powershell -ExecutionPolicy Bypass -File .\install\install-windows.ps1
# Alternative without a script: select the six .ttf files in fonts\ttf, right-click, choose Install (or "Install for all users").
# NOTE: this script was written on a Mac and has not been run on Windows.
$ErrorActionPreference = 'Stop'
$src  = Join-Path $PSScriptRoot '..\fonts\ttf'
$dest = Join-Path $env:LOCALAPPDATA 'Microsoft\Windows\Fonts'
$reg  = 'HKCU:\Software\Microsoft\Windows NT\CurrentVersion\Fonts'
$names = @{
  'Regular' = 'NSATS Sans Regular (TrueType)'
  'Italic' = 'NSATS Sans Italic (TrueType)'
  'SemiBold' = 'NSATS Sans SemiBold (TrueType)'
  'SemiBoldItalic' = 'NSATS Sans SemiBold Italic (TrueType)'
  'Bold' = 'NSATS Sans Bold (TrueType)'
  'BoldItalic' = 'NSATS Sans Bold Italic (TrueType)'
}
New-Item -ItemType Directory -Force -Path $dest | Out-Null
if (-not (Test-Path $reg)) { New-Item -Path $reg -Force | Out-Null }
foreach ($style in $names.Keys) {
  $file   = "NSATSSans-$style.ttf"
  $target = Join-Path $dest $file
  Copy-Item (Join-Path $src $file) $target -Force
  New-ItemProperty -Path $reg -Name $names[$style] -Value $target -PropertyType String -Force | Out-Null
  Write-Host "Installed $file"
}
Write-Host 'Done. Restart open applications (Word, PowerPoint, browsers) to see NSATS Sans.'
