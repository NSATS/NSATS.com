# Design applications

Install the fonts first (`install/INSTALL.md`). Applications group the six faces differently: some list all six under **NSATS Sans**, while others (including Microsoft Word) list SemiBold and SemiBold Italic separately as **NSATS Sans SemiBold**. None of the applications below has been tested with NSATS Sans; the notes summarise the vendors' documentation at the time of writing (October 2026), which can change.

| Application | How to use NSATS Sans |
|---|---|
| **Figma** | Local fonts: Figma's desktop app for macOS and Windows can use installed fonts; in a browser, Figma's font installer is needed, and that installer is available for macOS and Windows only (not Linux or ChromeOS). The desktop app includes the installer. Shared fonts (Organization and Enterprise plans only; not Starter or Professional): organisation admins can upload the `.ttf` files for the whole organisation, and team admins can upload them for a team. |
| **Adobe InDesign, Illustrator, Photoshop** | Installed fonts are normally available. For packaging, InDesign can copy fonts into a "Document Fonts" folder next to the .indd file (File > Package); the OFL allows this. Adobe documents that Metrics kerning uses the font's own kerning pairs, while Optical kerning sets spacing from the letter shapes instead. |
| **Affinity Designer / Publisher / Photo** | Installed fonts are normally available. Check that the font's kerning is in use in the character settings. |
| **Sketch** | Installed fonts are normally available. Make sure everyone who opens a shared document or library has NSATS Sans installed; check Sketch's current documentation for how missing fonts are handled. |
| **Canva** | Uploading fonts to a Brand Kit depends on your Canva plan and role; check Canva's current help pages. If available, upload the six `.ttf` files (the OFL permits this). |
| **Apple Pages, Keynote, Numbers** | Choose NSATS Sans in the Font panel (Pages and Keynote were tested on a Mac with the 1.202 fonts; Numbers was not tested). |
| **Google Docs / Slides** | These apps use the fonts in their own font list; an installed font such as NSATS Sans is not in that list. Choose a substitute from the list (Arial is a common choice). |

## Typography settings
- **Weights:** Regular 400, SemiBold 600, Bold 700 (each with an italic). No Light, Medium or variable font.
- **Headings:** SemiBold or Bold; **body:** Regular; avoid faux (synthetic) bold or italic.
- **Figures:** tabular by default; switch to proportional figures with the OpenType "Proportional" option (feature `pnum`) where the app offers it.
- **Kerning:** use the font's own kerning (called "Metrics", "Auto" or "Font" kerning, depending on the app).
- **Line spacing:** at least 1.2× the font size; increase it for text with stacked accents.

## Brand colours
The NSATS website palettes (cyan, carbon, royal) are in the distribution's `css/theme-tokens.css`.
