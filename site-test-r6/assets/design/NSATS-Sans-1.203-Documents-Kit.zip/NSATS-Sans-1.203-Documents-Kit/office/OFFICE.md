# Microsoft Office and Apple iWork

## Files
| File | Use |
|---|---|
| `NSATS-Sans-Word-Template.dotx` | Word template (A4): theme fonts NSATS Sans SemiBold (headings) / NSATS Sans (body), kerning on for all text, Title and Heading 1–3 styles |
| `NSATS-Sans-Word-Sample.docx` | the same content as an ordinary document |
| `NSATS-Sans-PowerPoint-Template.potx` | PowerPoint template (16:9): same theme fonts; kerning on from 1 pt |
| `NSATS-Sans-Theme-Fonts.xml` | Office theme-fonts file "NSATS Sans" (Headings: NSATS Sans SemiBold, Body: NSATS Sans) |

Install the fonts first (`install/INSTALL.md`).

## Word
- **Start from the template:** double-click the `.dotx` (a new document opens), or put it in your Word templates folder so it appears under File > New.
- **Kerning:** NSATS Sans's spacing improvements (for example K–ï and the Central European letters) are kerning pairs. Word applies them only when "Kerning for fonts" is on. The template turns it on for all styles. In other documents: Format > Font > Advanced (Mac) or Home > Font dialog > Advanced (Windows), tick **Kerning for fonts** and set **1 pt and above**; include it in your styles.
- **SemiBold:** Word lists it as a separate family, **NSATS Sans SemiBold**. Pressing Cmd/Ctrl+B in SemiBold text does not switch to Bold; choose NSATS Sans Bold instead (observed in Word for Mac with the 1.202 fonts).
- **Theme fonts (Windows):** copy `NSATS-Sans-Theme-Fonts.xml` to `%APPDATA%\Microsoft\Templates\Document Themes\Theme Fonts\`; "NSATS Sans" should then appear under Design > Fonts. This step has not been tested. On a Mac, use the templates.
- **Sharing .docx files:** recipients without the fonts see a substitute. Microsoft documents font embedding in Word (on Windows: File > Options > Save > Embed fonts in the file); NSATS Sans allows embedding (fsType 0). Embedding NSATS Sans in Word has not been tested.
- **PDF:** File > Save As > PDF. Check the PDF's font list (section "Checking a PDF" in `print-and-pdf/PRINT-AND-PDF.md`).

## PowerPoint
Open the `.potx` (or File > New from template) and keep the theme fonts so that titles use NSATS Sans SemiBold and text uses NSATS Sans. Kerning is set on in the template's master. Delete the two sample slides.

## Excel
Set the workbook's theme fonts to "NSATS Sans" (Windows, after installing the theme-fonts file) or choose NSATS Sans in the cell styles. Tabular figures are the default, which keeps columns of numbers aligned.

## Pages, Keynote and Numbers (Mac)
Choose **NSATS Sans** in the Format > Font panel; if SemiBold is listed separately, choose **NSATS Sans SemiBold**. In the 1.202 Mac tests, Pages and Keynote applied the font's kerning. To convert an older document, Apple documents Format > Font > Replace Fonts…: replace NSATS Clear with NSATS Sans (not tested with 1.203).

## Google Docs, Slides and Sheets
These apps offer the fonts in their own font list; a font installed on your computer, such as NSATS Sans, is not in that list. Choose a substitute from the list (Arial is a common choice; no comparison has been made), or write in Word or Pages and share a PDF.

## Tested
The template files were checked on Linux with an Office schema validator and rendered with LibreOffice. That is structural checking only: they have not been opened in Microsoft Word, PowerPoint or Excel. Statements above about Word, Pages and Keynote behaviour come from native Mac tests made with the 1.202 fonts (then named NSATS Clear), whose glyphs, spacing and kerning are identical to 1.203.
